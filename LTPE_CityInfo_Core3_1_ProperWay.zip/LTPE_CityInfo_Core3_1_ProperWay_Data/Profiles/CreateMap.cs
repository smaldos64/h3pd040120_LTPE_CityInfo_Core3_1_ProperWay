﻿namespace LTPE_CityInfo_Core3_1_ProperWay_Data.Profiles
{
    internal class CreateMap<T1, T2>
    {
    }
}