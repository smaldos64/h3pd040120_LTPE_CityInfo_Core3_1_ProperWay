﻿using System;

namespace LTPE_CityInfo_Core3_1_ProperWay_Data
{
    public class Class1
    {
    }
}
