﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LTPE_CityInfo_Core3_1_ProperWay_Data.Models
{
    public class LanguageDtoMinusRelations
    {
        public int Id { get; set; }
        public string LanguageName { get; set; }
    }
}
