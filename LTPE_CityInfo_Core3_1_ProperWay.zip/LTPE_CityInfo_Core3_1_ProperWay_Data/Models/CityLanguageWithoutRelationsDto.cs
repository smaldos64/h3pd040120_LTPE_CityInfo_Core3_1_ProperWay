﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LTPE_CityInfo_Core3_1_ProperWay_Data.Models
{
    public class CityLanguageWithoutRelationsDto
    {
        public int CityId { get; set; }

        public int LanguageId { get; set; }
    }
}
