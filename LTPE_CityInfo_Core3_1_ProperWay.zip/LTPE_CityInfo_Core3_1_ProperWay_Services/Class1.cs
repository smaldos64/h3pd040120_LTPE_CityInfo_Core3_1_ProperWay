﻿using System;

namespace LTPE_CityInfo_Core3_1_ProperWay_Services
{
    public class Class1
    {
    }
}
