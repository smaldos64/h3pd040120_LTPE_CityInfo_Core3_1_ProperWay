﻿using System;

namespace LTPE_CityInfo_Core3_1_ProperWay_Data_Async
{
    public class Class1
    {
    }
}
