﻿namespace LTPE_CityInfo_Core3_1_ProperWay_Data_Async.Profiles
{
    internal class CreateMap<T1, T2>
    {
    }
}